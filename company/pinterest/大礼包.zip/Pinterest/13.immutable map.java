// https://www.geeksforgeeks.org/immutable-map-in-java/

// Java code illustrating of() method to 
// create a ImmutableSet 
import java.util.*; 
import com.google.common.collect.ImmutableMap; 

class GfG { 
    public static void main(String args[]) 
    { 
        // non-empty immutable set 
        ImmutableMap<Integer, String> imap = 
                        ImmutableMap.<Integer, String>builder() 
                                                .put(1, "Geeks") 
                                                .put(2, "For") 
                                                .put(3, "Geeks") 
                                                .build(); 

        // Let's print the set 
        System.out.println(imap); 
    } 
} 
